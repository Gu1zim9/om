import React, { useState, useEffect } from 'react';
import { LoginForm } from './components/auth/LoginForm';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { AdminDashboard } from './components/dashboard/AdminDashboard';
import { ApplicationsPage } from './components/applications/ApplicationsPage';
import { PaymentsPage } from './components/payments/PaymentsPage';
import { ClientDashboard } from './components/clients/ClientDashboard';
import { DeployWizard } from './components/deploy/DeployWizard';
import { useAuthStore } from './store/authStore';
import { useApplicationStore } from './store/applicationStore';
import { useThemeStore } from './store/themeStore';

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showDeployWizard, setShowDeployWizard] = useState(false);
  
  const { isAuthenticated, user } = useAuthStore();
  const { deployApplication } = useApplicationStore();
  const { isDark } = useThemeStore();

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const getPageTitle = () => {
    switch (currentPage) {
      case 'dashboard': return user?.role === 'admin' ? 'Dashboard Administrativo' : 'Meu Dashboard';
      case 'applications': return 'Aplicações';
      case 'clients': return 'Clientes';
      case 'payments': return 'Pagamentos';
      case 'system': return 'Sistema';
      case 'settings': return 'Configurações';
      default: return 'Dashboard';
    }
  };

  const handleDeploy = async (appData: any) => {
    await deployApplication({
      ...appData,
      userId: user?.id,
      clientName: appData.client,
    });
    setShowDeployWizard(false);
  };

  if (!isAuthenticated) {
    return (
      <div className={`min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4 ${isDark ? 'dark' : ''}`}>
        <LoginForm />
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-gray-50 dark:bg-gray-900 ${isDark ? 'dark' : ''}`}>
      <div className="flex h-screen">
        {user?.role === 'admin' && (
          <Sidebar
            currentPage={currentPage}
            onPageChange={setCurrentPage}
            isCollapsed={sidebarCollapsed}
            onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          />
        )}
        
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header title={getPageTitle()} />
          
          <main className="flex-1 overflow-y-auto p-6">
            {user?.role === 'admin' ? (
              <>
                {currentPage === 'dashboard' && (
                  <AdminDashboard onAddProject={() => setShowDeployWizard(true)} />
                )}
                {currentPage === 'applications' && (
                  <ApplicationsPage onAddProject={() => setShowDeployWizard(true)} />
                )}
                {currentPage === 'payments' && <PaymentsPage />}
                {currentPage === 'clients' && (
                  <div className="text-center py-12">
                    <div className="text-gray-500 dark:text-gray-400">
                      Página de clientes em desenvolvimento
                    </div>
                  </div>
                )}
                {currentPage === 'system' && (
                  <div className="text-center py-12">
                    <div className="text-gray-500 dark:text-gray-400">
                      Página de sistema em desenvolvimento
                    </div>
                  </div>
                )}
                {currentPage === 'settings' && (
                  <div className="text-center py-12">
                    <div className="text-gray-500 dark:text-gray-400">
                      Página de configurações em desenvolvimento
                    </div>
                  </div>
                )}
              </>
            ) : (
              <ClientDashboard />
            )}
          </main>
        </div>
      </div>

      {/* Deploy Wizard */}
      <DeployWizard
        isOpen={showDeployWizard}
        onClose={() => setShowDeployWizard(false)}
        onDeploy={handleDeploy}
      />
    </div>
  );
}

export default App;