import React from 'react';
import { CreditCard, TrendingUp, AlertCircle, CheckCircle, XCircle } from 'lucide-react';

export const PaymentsPage: React.FC = () => {
  const mockPayments = [
    {
      id: '1',
      client: 'João Silva',
      amount: 197,
      status: 'paid',
      method: 'stripe',
      date: '2024-01-20',
      plan: 'Pro'
    },
    {
      id: '2',
      client: 'Google User',
      amount: 97,
      status: 'pending',
      method: 'mercadopago',
      date: '2024-01-19',
      plan: 'Básico'
    },
    {
      id: '3',
      client: 'Maria Santos',
      amount: 497,
      status: 'failed',
      method: 'stripe',
      date: '2024-01-18',
      plan: 'Enterprise'
    },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid': return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'pending': return <AlertCircle className="w-5 h-5 text-yellow-600" />;
      case 'failed': return <XCircle className="w-5 h-5 text-red-600" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'failed': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
          Sistema de Pagamentos
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          Controle financeiro completo e automático
        </p>
      </div>

      {/* Financial Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center space-x-3 mb-2">
            <TrendingUp className="w-6 h-6 text-green-600" />
            <span className="font-semibold text-gray-900 dark:text-white">Receita Total</span>
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            R$28.500
          </p>
          <p className="text-sm text-green-600 dark:text-green-400">
            +23% este mês
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center space-x-3 mb-2">
            <CheckCircle className="w-6 h-6 text-blue-600" />
            <span className="font-semibold text-gray-900 dark:text-white">Pagamentos OK</span>
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            89%
          </p>
          <p className="text-sm text-blue-600 dark:text-blue-400">
            Taxa de sucesso
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center space-x-3 mb-2">
            <AlertCircle className="w-6 h-6 text-yellow-600" />
            <span className="font-semibold text-gray-900 dark:text-white">Pendentes</span>
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            5
          </p>
          <p className="text-sm text-yellow-600 dark:text-yellow-400">
            Precisam atenção
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center space-x-3 mb-2">
            <XCircle className="w-6 h-6 text-red-600" />
            <span className="font-semibold text-gray-900 dark:text-white">Falharam</span>
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            2
          </p>
          <p className="text-sm text-red-600 dark:text-red-400">
            Requer ação
          </p>
        </div>
      </div>

      {/* Payments Table */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 overflow-hidden">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Histórico de Pagamentos
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Cliente
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Plano
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Valor
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Método
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Data
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {mockPayments.map((payment) => (
                <tr key={payment.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="font-medium text-gray-900 dark:text-white">
                      {payment.client}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-gray-900 dark:text-white">
                      {payment.plan}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="font-semibold text-gray-900 dark:text-white">
                      R${payment.amount}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(payment.status)}
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(payment.status)}`}>
                        {payment.status === 'paid' ? 'Pago' : payment.status === 'pending' ? 'Pendente' : 'Falhou'}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-gray-900 dark:text-white capitalize">
                      {payment.method}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-600 dark:text-gray-400">
                    {new Date(payment.date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button className="text-blue-600 hover:text-blue-700 dark:text-blue-400 font-medium text-sm">
                      Ver Detalhes
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Automatic Billing Config */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Configuração de Cobrança Automática
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h4 className="font-medium text-gray-900 dark:text-white">
              Fluxo Automático
            </h4>
            <div className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Aviso 5 dias antes do vencimento</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Cobrança automática no vencimento</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                <span>Retry em 3 e 7 dias se falhar</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <span>Suspensão após 15 dias</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-medium text-gray-900 dark:text-white">
              Métodos de Pagamento
            </h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-600 rounded-lg">
                <span className="text-gray-900 dark:text-white">Stripe (Internacional)</span>
                <span className="text-green-600 dark:text-green-400 text-sm">Ativo</span>
              </div>
              <div className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-600 rounded-lg">
                <span className="text-gray-900 dark:text-white">Mercado Pago (Brasil)</span>
                <span className="text-green-600 dark:text-green-400 text-sm">Ativo</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};