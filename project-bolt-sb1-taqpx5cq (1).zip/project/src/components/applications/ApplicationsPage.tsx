import React, { useState, useEffect } from 'react';
import { Plus, Search, Filter } from 'lucide-react';
import { ApplicationCard } from './ApplicationCard';
import { LogsModal } from './LogsModal';
import { useApplicationStore } from '../../store/applicationStore';
import { Application } from '../../types';

interface ApplicationsPageProps {
  onAddProject: () => void;
}

export const ApplicationsPage: React.FC<ApplicationsPageProps> = ({ onAddProject }) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'running' | 'stopped'>('all');
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);
  const [showLogsModal, setShowLogsModal] = useState(false);
  
  const {
    applications,
    logs,
    isLoading,
    fetchApplications,
    toggleApplicationStatus,
    removeApplication,
    fetchLogs,
  } = useApplicationStore();

  useEffect(() => {
    fetchApplications();
  }, [fetchApplications]);

  const filteredApplications = applications.filter(app => {
    const matchesSearch = app.name.toLowerCase().includes(search.toLowerCase()) ||
                         app.clientName.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'all' || app.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleViewLogs = async (app: Application) => {
    setSelectedApp(app);
    await fetchLogs(app.id);
    setShowLogsModal(true);
  };

  const handleRemove = async (appId: string) => {
    if (window.confirm('Tem certeza que deseja remover esta aplicação? Esta ação é irreversível.')) {
      if (window.confirm('CONFIRMAÇÃO FINAL: Todos os dados serão perdidos. Continuar?')) {
        await removeApplication(appId);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
            Gerenciamento de Aplicações
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Controle completo de todas as aplicações hospedadas
          </p>
        </div>
        <button
          onClick={onAddProject}
          className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-medium transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>Nova Aplicação</span>
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
        <div className="flex items-center space-x-4">
          <div className="flex-1 max-w-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar aplicações..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Filter className="w-4 h-4 text-gray-500" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="all">Todos Status</option>
              <option value="running">Executando</option>
              <option value="stopped">Parado</option>
            </select>
          </div>
        </div>
      </div>

      {/* Applications Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
              <div className="animate-pulse space-y-4">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                <div className="space-y-2">
                  <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded"></div>
                </div>
                <div className="flex space-x-2">
                  <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded flex-1"></div>
                  <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded flex-1"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : filteredApplications.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredApplications.map((app) => (
            <ApplicationCard
              key={app.id}
              application={app}
              onToggleStatus={toggleApplicationStatus}
              onViewLogs={handleViewLogs}
              onRemove={handleRemove}
              isLoading={isLoading}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <Server className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
            Nenhuma aplicação encontrada
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Comece adicionando sua primeira aplicação à plataforma
          </p>
          <button
            onClick={onAddProject}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-medium transition-colors"
          >
            Adicionar Primeira Aplicação
          </button>
        </div>
      )}

      {/* Logs Modal */}
      <LogsModal
        isOpen={showLogsModal}
        onClose={() => setShowLogsModal(false)}
        application={selectedApp}
        logs={logs}
      />
    </div>
  );
};