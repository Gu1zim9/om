import React from 'react';
import { 
  Play, 
  Pause, 
  MoreVertical, 
  ExternalLink, 
  Trash2, 
  FileText,
  Cpu,
  HardDrive,
  Activity
} from 'lucide-react';
import { Application } from '../../types';

interface ApplicationCardProps {
  application: Application;
  onToggleStatus: (appId: string) => void;
  onViewLogs: (app: Application) => void;
  onRemove: (appId: string) => void;
  isLoading: boolean;
}

export const ApplicationCard: React.FC<ApplicationCardProps> = ({
  application,
  onToggleStatus,
  onViewLogs,
  onRemove,
  isLoading,
}) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'stopped': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      case 'deploying': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'error': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-400';
    }
  };

  const getTechColor = (tech: string) => {
    switch (tech) {
      case 'nodejs': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'socketio': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400';
      case 'python': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400';
      case 'php': return 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/20 dark:text-indigo-400';
      case 'static': return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-400';
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700 hover:shadow-lg transition-all duration-300">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-3 mb-2">
            <h3 className="font-semibold text-gray-900 dark:text-white text-lg">
              {application.name}
            </h3>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(application.status)}`}>
              {application.status}
            </span>
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">
            Cliente: {application.clientName}
          </p>
          <a 
            href={`https://${application.domain}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400 flex items-center space-x-1"
          >
            <span>{application.domain}</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
        
        <div className="flex items-center space-x-2">
          <span className={`px-2 py-1 rounded-lg text-xs font-medium ${getTechColor(application.technology)}`}>
            {application.technology.toUpperCase()}
          </span>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-3 gap-4 mb-4">
        <div className="text-center">
          <div className="flex items-center justify-center space-x-1 mb-1">
            <Cpu className="w-4 h-4 text-blue-600" />
            <span className="text-xs text-gray-500 dark:text-gray-400">CPU</span>
          </div>
          <p className="text-sm font-semibold text-gray-900 dark:text-white">
            {application.resources.cpu}%
          </p>
        </div>
        <div className="text-center">
          <div className="flex items-center justify-center space-x-1 mb-1">
            <HardDrive className="w-4 h-4 text-green-600" />
            <span className="text-xs text-gray-500 dark:text-gray-400">RAM</span>
          </div>
          <p className="text-sm font-semibold text-gray-900 dark:text-white">
            {application.resources.ram}%
          </p>
        </div>
        <div className="text-center">
          <div className="flex items-center justify-center space-x-1 mb-1">
            <Activity className="w-4 h-4 text-orange-600" />
            <span className="text-xs text-gray-500 dark:text-gray-400">Uptime</span>
          </div>
          <p className="text-sm font-semibold text-gray-900 dark:text-white">
            {application.metrics.uptime}%
          </p>
        </div>
      </div>

      {/* Resource bars */}
      <div className="space-y-2 mb-4">
        <div>
          <div className="flex justify-between text-xs text-gray-600 dark:text-gray-400 mb-1">
            <span>CPU Usage</span>
            <span>{application.resources.cpu}%</span>
          </div>
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${application.resources.cpu}%` }}
            />
          </div>
        </div>
        <div>
          <div className="flex justify-between text-xs text-gray-600 dark:text-gray-400 mb-1">
            <span>Memory Usage</span>
            <span>{application.resources.ram}%</span>
          </div>
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
            <div
              className="bg-green-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${application.resources.ram}%` }}
            />
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center space-x-2">
        <button
          onClick={() => onToggleStatus(application.id)}
          disabled={isLoading}
          className={`flex items-center space-x-2 px-3 py-2 rounded-lg font-medium text-sm transition-colors ${
            application.status === 'running'
              ? 'bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/20 dark:text-red-400'
              : 'bg-green-100 text-green-700 hover:bg-green-200 dark:bg-green-900/20 dark:text-green-400'
          } disabled:opacity-50`}
        >
          {application.status === 'running' ? (
            <>
              <Pause className="w-4 h-4" />
              <span>Pausar</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4" />
              <span>Iniciar</span>
            </>
          )}
        </button>

        <button
          onClick={() => onViewLogs(application)}
          className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-blue-100 text-blue-700 hover:bg-blue-200 dark:bg-blue-900/20 dark:text-blue-400 font-medium text-sm transition-colors"
        >
          <FileText className="w-4 h-4" />
          <span>Logs</span>
        </button>

        <button
          onClick={() => onRemove(application.id)}
          className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/20 dark:text-red-400 font-medium text-sm transition-colors"
        >
          <Trash2 className="w-4 h-4" />
          <span>Remover</span>
        </button>
      </div>
    </div>
  );
};