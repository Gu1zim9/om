import React from 'react';

interface RevenueChartProps {
  data: Array<{ month: string; revenue: number }>;
}

export const RevenueChart: React.FC<RevenueChartProps> = ({ data }) => {
  const maxRevenue = Math.max(...data.map(d => d.revenue));

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Receita dos Últimos 6 Meses
        </h3>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
          <span className="text-sm text-gray-600 dark:text-gray-400">Receita</span>
        </div>
      </div>

      <div className="h-64 flex items-end justify-between space-x-2">
        {data.map((item, index) => {
          const height = (item.revenue / maxRevenue) * 100;
          
          return (
            <div key={index} className="flex flex-col items-center flex-1">
              <div className="w-full bg-gray-100 dark:bg-gray-700 rounded-t-lg relative overflow-hidden">
                <div
                  className="bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-lg transition-all duration-1000 ease-out"
                  style={{ height: `${Math.max(height, 5)}%` }}
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-xs font-semibold text-white opacity-90">
                    R${item.revenue}k
                  </span>
                </div>
              </div>
              <span className="text-xs text-gray-600 dark:text-gray-400 mt-2 font-medium">
                {item.month}
              </span>
            </div>
          );
        })}
      </div>

      <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
        <div className="flex items-center justify-between">
          <span className="text-blue-700 dark:text-blue-400 font-medium">
            Projeção para próximo mês
          </span>
          <span className="text-blue-900 dark:text-blue-300 font-bold">
            R${Math.round(data[data.length - 1].revenue * 1.15)}k
          </span>
        </div>
      </div>
    </div>
  );
};