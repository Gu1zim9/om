import React, { useEffect } from 'react';
import { 
  Server, 
  Users, 
  DollarSign, 
  Activity,
  TrendingUp,
  AlertTriangle,
  Plus
} from 'lucide-react';
import { MetricCard } from './MetricCard';
import { RevenueChart } from './RevenueChart';
import { useApplicationStore } from '../../store/applicationStore';

interface AdminDashboardProps {
  onAddProject: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onAddProject }) => {
  const { applications, fetchApplications } = useApplicationStore();

  useEffect(() => {
    fetchApplications();
  }, [fetchApplications]);

  const metrics = {
    totalApplications: applications.length,
    activeClients: new Set(applications.map(app => app.userId)).size,
    monthlyRevenue: 28500,
    averageUptime: applications.length > 0 
      ? applications.reduce((acc, app) => acc + app.metrics.uptime, 0) / applications.length 
      : 0,
  };

  const revenueData = [
    { month: 'Jul', revenue: 15 },
    { month: 'Ago', revenue: 18 },
    { month: 'Set', revenue: 22 },
    { month: 'Out', revenue: 25 },
    { month: 'Nov', revenue: 28 },
    { month: 'Dez', revenue: 32 },
  ];

  const recentApplications = applications
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const pendingPayments = applications.filter(app => app.paymentStatus === 'pending');

  return (
    <div className="space-y-6">
      {/* Action Button */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
            Dashboard Administrativo
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Visão geral da plataforma e métricas em tempo real
          </p>
        </div>
        <button
          onClick={onAddProject}
          className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-medium transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>Adicionar Projeto</span>
        </button>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Aplicações Ativas"
          value={metrics.totalApplications}
          change="+12% este mês"
          changeType="positive"
          icon={Server}
          iconColor="bg-blue-600"
        />
        <MetricCard
          title="Clientes Ativos"
          value={metrics.activeClients}
          change="+8% este mês"
          changeType="positive"
          icon={Users}
          iconColor="bg-green-600"
        />
        <MetricCard
          title="Receita Mensal"
          value={`R$${metrics.monthlyRevenue.toLocaleString()}`}
          change="+23% este mês"
          changeType="positive"
          icon={DollarSign}
          iconColor="bg-yellow-600"
        />
        <MetricCard
          title="Uptime Médio"
          value={`${metrics.averageUptime.toFixed(1)}%`}
          change="SLA: 99.9%"
          changeType="positive"
          icon={Activity}
          iconColor="bg-purple-600"
        />
      </div>

      {/* Charts and Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <RevenueChart data={revenueData} />
        
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Aplicações Recentes
          </h3>
          <div className="space-y-3">
            {recentApplications.map((app) => (
              <div key={app.id} className="flex items-center justify-between p-3 rounded-xl bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${
                    app.status === 'running' ? 'bg-green-500' : 'bg-red-500'
                  }`} />
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">
                      {app.name}
                    </p>
                    <p className="text-xs text-gray-600 dark:text-gray-400">
                      {app.clientName}
                    </p>
                  </div>
                </div>
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {new Date(app.createdAt).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Alerts */}
      {pendingPayments.length > 0 && (
        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-2xl p-6">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
            <div>
              <h3 className="font-semibold text-yellow-800 dark:text-yellow-300">
                Pagamentos Pendentes
              </h3>
              <p className="text-yellow-700 dark:text-yellow-400">
                {pendingPayments.length} aplicação(ões) com pagamento pendente
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};