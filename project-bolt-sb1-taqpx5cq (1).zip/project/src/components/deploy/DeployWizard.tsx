import React, { useState } from 'react';
import { X, Upload, FileText, Settings, Rocket, Check } from 'lucide-react';

interface DeployWizardProps {
  isOpen: boolean;
  onClose: () => void;
  onDeploy: (appData: any) => void;
}

const steps = [
  { id: 1, title: 'Upload', icon: Upload },
  { id: 2, title: 'Detecção', icon: FileText },
  { id: 3, title: 'Configuração', icon: Settings },
  { id: 4, title: 'Deploy', icon: Rocket },
];

export const DeployWizard: React.FC<DeployWizardProps> = ({
  isOpen,
  onClose,
  onDeploy,
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [detectedTech, setDetectedTech] = useState<string>('');
  const [appConfig, setAppConfig] = useState({
    name: '',
    client: '',
    technology: '',
    port: 3000,
    cpu: 1,
    ram: 512,
    envVars: '',
  });
  const [isDeploying, setIsDeploying] = useState(false);
  const [deployLogs, setDeployLogs] = useState<string[]>([]);

  const simulateUpload = async () => {
    for (let i = 0; i <= 100; i += 10) {
      setUploadProgress(i);
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    // Simulate technology detection
    await new Promise(resolve => setTimeout(resolve, 500));
    const techs = ['nodejs', 'socketio', 'python', 'static'];
    const detected = techs[Math.floor(Math.random() * techs.length)];
    setDetectedTech(detected);
    setAppConfig(prev => ({ ...prev, technology: detected }));
    setCurrentStep(2);
  };

  const simulateDeploy = async () => {
    setIsDeploying(true);
    setCurrentStep(4);
    
    const logs = [
      'Iniciando processo de deploy...',
      'Criando container Docker...',
      'Instalando dependências...',
      'Configurando variáveis de ambiente...',
      'Gerando Dockerfile otimizado...',
      'Executando build da aplicação...',
      'Configurando proxy reverso...',
      'Gerando certificado SSL...',
      'Aplicação disponível em: https://test-app.dls.com',
      'Deploy concluído com sucesso!'
    ];

    for (let i = 0; i < logs.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 500));
      setDeployLogs(prev => [...prev, logs[i]]);
    }

    await new Promise(resolve => setTimeout(resolve, 1000));
    onDeploy(appConfig);
    onClose();
    resetWizard();
  };

  const resetWizard = () => {
    setCurrentStep(1);
    setUploadProgress(0);
    setDetectedTech('');
    setAppConfig({
      name: '',
      client: '',
      technology: '',
      port: 3000,
      cpu: 1,
      ram: 512,
      envVars: '',
    });
    setIsDeploying(false);
    setDeployLogs([]);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            Deploy Nova Aplicação
          </h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Steps */}
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isActive = currentStep === step.id;
              const isCompleted = currentStep > step.id;
              
              return (
                <div key={step.id} className="flex items-center">
                  <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                    isCompleted 
                      ? 'bg-green-600 border-green-600 text-white'
                      : isActive
                      ? 'bg-blue-600 border-blue-600 text-white'
                      : 'border-gray-300 dark:border-gray-600 text-gray-400'
                  }`}>
                    {isCompleted ? (
                      <Check className="w-5 h-5" />
                    ) : (
                      <Icon className="w-5 h-5" />
                    )}
                  </div>
                  <span className={`ml-2 text-sm font-medium ${
                    isActive ? 'text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400'
                  }`}>
                    {step.title}
                  </span>
                  {index < steps.length - 1 && (
                    <div className="w-12 h-0.5 bg-gray-300 dark:bg-gray-600 mx-4" />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {currentStep === 1 && (
            <div className="text-center">
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-2xl p-12 hover:border-blue-400 transition-colors">
                <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Upload do Projeto
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Arraste e solte sua pasta ou arquivo ZIP (até 500MB)
                </p>
                <button
                  onClick={simulateUpload}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-medium transition-colors"
                >
                  Selecionar Arquivos
                </button>
              </div>
              
              {uploadProgress > 0 && (
                <div className="mt-6">
                  <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
                    <span>Upload em progresso...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
                    <div
                      className="bg-blue-600 h-3 rounded-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {currentStep === 2 && (
            <div className="text-center">
              <div className="bg-green-50 dark:bg-green-900/20 rounded-2xl p-8">
                <Check className="w-16 h-16 text-green-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Tecnologia Detectada
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Sistema detectou automaticamente: <strong>{detectedTech.toUpperCase()}</strong>
                </p>
                
                <div className="grid grid-cols-2 gap-4 text-left">
                  <div className="bg-white dark:bg-gray-800 p-4 rounded-xl border">
                    <h4 className="font-medium text-gray-900 dark:text-white mb-2">Arquivos Detectados</h4>
                    <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                      <li>• package.json</li>
                      <li>• server.js</li>
                      <li>• public/index.html</li>
                      <li>• src/components/</li>
                    </ul>
                  </div>
                  <div className="bg-white dark:bg-gray-800 p-4 rounded-xl border">
                    <h4 className="font-medium text-gray-900 dark:text-white mb-2">Configurações Auto</h4>
                    <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                      <li>• Node.js 18.x</li>
                      <li>• Socket.IO support</li>
                      <li>• PM2 clustering</li>
                      <li>• SSL automático</li>
                    </ul>
                  </div>
                </div>

                <button
                  onClick={() => setCurrentStep(3)}
                  className="mt-6 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-medium transition-colors"
                >
                  Continuar para Configuração
                </button>
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Nome da Aplicação
                  </label>
                  <input
                    type="text"
                    value={appConfig.name}
                    onChange={(e) => setAppConfig(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Minha Aplicação"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Cliente
                  </label>
                  <select
                    value={appConfig.client}
                    onChange={(e) => setAppConfig(prev => ({ ...prev, client: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="">Selecionar cliente</option>
                    <option value="João Silva">João Silva</option>
                    <option value="Google User">Google User</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    CPU (cores)
                  </label>
                  <input
                    type="number"
                    value={appConfig.cpu}
                    onChange={(e) => setAppConfig(prev => ({ ...prev, cpu: parseInt(e.target.value) }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    min="1"
                    max="8"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    RAM (MB)
                  </label>
                  <input
                    type="number"
                    value={appConfig.ram}
                    onChange={(e) => setAppConfig(prev => ({ ...prev, ram: parseInt(e.target.value) }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    min="256"
                    max="4096"
                    step="256"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Porta
                  </label>
                  <input
                    type="number"
                    value={appConfig.port}
                    onChange={(e) => setAppConfig(prev => ({ ...prev, port: parseInt(e.target.value) }))}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    min="3000"
                    max="9999"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Variáveis de Ambiente
                </label>
                <textarea
                  value={appConfig.envVars}
                  onChange={(e) => setAppConfig(prev => ({ ...prev, envVars: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  rows={4}
                  placeholder="NODE_ENV=production&#10;DATABASE_URL=..."
                />
              </div>

              <button
                onClick={simulateDeploy}
                disabled={!appConfig.name || !appConfig.client}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-6 py-3 rounded-xl font-medium transition-colors"
              >
                Iniciar Deploy
              </button>
            </div>
          )}

          {currentStep === 4 && (
            <div>
              <div className="bg-gray-900 rounded-2xl p-6 font-mono text-sm">
                <div className="flex items-center space-x-2 mb-4">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-green-400">Deploy em tempo real</span>
                </div>
                
                <div className="space-y-1 max-h-64 overflow-y-auto">
                  {deployLogs.map((log, index) => (
                    <div key={index} className="text-green-400">
                      $ {log}
                    </div>
                  ))}
                  {isDeploying && (
                    <div className="text-green-400 flex items-center space-x-2">
                      <span>$</span>
                      <div className="w-2 h-4 bg-green-400 animate-pulse"></div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};