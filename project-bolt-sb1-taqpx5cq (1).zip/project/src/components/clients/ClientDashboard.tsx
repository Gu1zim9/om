import React from 'react';
import { ExternalLink, Activity, Users, CreditCard } from 'lucide-react';
import { useApplicationStore } from '../../store/applicationStore';
import { useAuthStore } from '../../store/authStore';

export const ClientDashboard: React.FC = () => {
  const { applications } = useApplicationStore();
  const { user } = useAuthStore();

  const clientApps = applications.filter(app => app.userId === user?.id);

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">
          Bem-vindo, {user?.name}!
        </h1>
        <p className="text-blue-100">
          Gerencie suas aplicações hospedadas na DLS Platform
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center space-x-3 mb-2">
            <Activity className="w-6 h-6 text-green-600" />
            <span className="font-semibold text-gray-900 dark:text-white">Uptime Médio</span>
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            {clientApps.length > 0 
              ? (clientApps.reduce((acc, app) => acc + app.metrics.uptime, 0) / clientApps.length).toFixed(1)
              : '0'
            }%
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center space-x-3 mb-2">
            <Users className="w-6 h-6 text-blue-600" />
            <span className="font-semibold text-gray-900 dark:text-white">Visitantes</span>
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            {clientApps.reduce((acc, app) => acc + app.metrics.visitors, 0).toLocaleString()}
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center space-x-3 mb-2">
            <CreditCard className="w-6 h-6 text-green-600" />
            <span className="font-semibold text-gray-900 dark:text-white">Status</span>
          </div>
          <p className="text-2xl font-bold text-green-600">
            Ativo
          </p>
        </div>
      </div>

      {/* Applications */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
          Suas Aplicações
        </h2>
        
        {clientApps.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {clientApps.map((app) => (
              <div key={app.id} className="border border-gray-200 dark:border-gray-700 rounded-xl p-4 hover:shadow-md transition-all">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-gray-900 dark:text-white">
                    {app.name}
                  </h3>
                  <div className={`w-3 h-3 rounded-full ${
                    app.status === 'running' ? 'bg-green-500' : 'bg-red-500'
                  }`} />
                </div>

                <div className="space-y-3 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Uptime:</span>
                    <span className="font-medium text-gray-900 dark:text-white">
                      {app.metrics.uptime}%
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Visitantes:</span>
                    <span className="font-medium text-gray-900 dark:text-white">
                      {app.metrics.visitors.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Resp. Time:</span>
                    <span className="font-medium text-gray-900 dark:text-white">
                      {app.metrics.responseTime}ms
                    </span>
                  </div>
                </div>

                <a
                  href={`https://${app.domain}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg font-medium transition-colors"
                >
                  <span>Acessar Aplicação</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Activity className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              Nenhuma aplicação hospedada
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Entre em contato com o administrador para hospedar sua primeira aplicação
            </p>
          </div>
        )}
      </div>

      {/* Support */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
          Suporte Técnico
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium text-gray-900 dark:text-white mb-2">
              FAQ Rápido
            </h3>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li>• Como acessar minha aplicação?</li>
              <li>• Problemas de conectividade</li>
              <li>• Configurações de domínio</li>
              <li>• Backup e restore</li>
            </ul>
          </div>
          <div>
            <h3 className="font-medium text-gray-900 dark:text-white mb-2">
              Contato Direto
            </h3>
            <button className="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg font-medium transition-colors">
              Abrir Ticket de Suporte
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};