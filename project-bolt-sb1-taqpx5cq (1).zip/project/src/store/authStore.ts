import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User } from '../types';

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => void;
  register: (email: string, password: string, name: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  setUser: (user: User) => void;
}

// Mock data for demo
const mockUsers: User[] = [
  {
    id: '1',
    email: 'administrator',
    name: 'Administrator',
    role: 'admin',
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '2',
    email: 'client@example.com',
    name: 'João Silva',
    role: 'client',
    createdAt: '2024-01-15T00:00:00Z',
  }
];

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,

      login: async (email: string, password: string) => {
        set({ isLoading: true });
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const user = mockUsers.find(u => u.email === email);
        if (user && password === 'password123') {
          const token = 'mock-jwt-token-' + user.id;
          set({
            user,
            token,
            isAuthenticated: true,
            isLoading: false,
          });
        } else {
          set({ isLoading: false });
          throw new Error('Credenciais inválidas');
        }
      },

      loginWithGoogle: async () => {
        set({ isLoading: true });
        
        // Simulate Google OAuth
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        const user: User = {
          id: '3',
          email: 'user@gmail.com',
          name: 'Google User',
          role: 'client',
          googleId: 'google-123',
          createdAt: new Date().toISOString(),
        };
        
        const token = 'mock-jwt-token-google';
        set({
          user,
          token,
          isAuthenticated: true,
          isLoading: false,
        });
      },

      logout: () => {
        set({
          user: null,
          token: null,
          isAuthenticated: false,
        });
      },

      register: async (email: string, password: string, name: string) => {
        set({ isLoading: true });
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const user: User = {
          id: Date.now().toString(),
          email,
          name,
          role: 'client',
          createdAt: new Date().toISOString(),
        };
        
        const token = 'mock-jwt-token-' + user.id;
        set({
          user,
          token,
          isAuthenticated: true,
          isLoading: false,
        });
      },

      resetPassword: async (email: string) => {
        set({ isLoading: true });
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        set({ isLoading: false });
        // In real implementation, would send email
      },

      setUser: (user: User) => {
        set({ user });
      },
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        user: state.user,
        token: state.token,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);