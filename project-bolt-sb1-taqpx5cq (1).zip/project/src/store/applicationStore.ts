import { create } from 'zustand';
import { Application, SystemLog } from '../types';

interface ApplicationState {
  applications: Application[];
  logs: SystemLog[];
  isLoading: boolean;
  selectedApp: Application | null;
  fetchApplications: () => Promise<void>;
  toggleApplicationStatus: (appId: string) => Promise<void>;
  removeApplication: (appId: string) => Promise<void>;
  fetchLogs: (appId: string) => Promise<void>;
  setSelectedApp: (app: Application | null) => void;
  deployApplication: (appData: any) => Promise<void>;
}

// Mock data
const mockApplications: Application[] = [
  {
    id: '1',
    name: 'Sistema Creperia',
    userId: '2',
    clientName: 'João Silva',
    domain: 'creperia.dls.com',
    port: 3000,
    status: 'running',
    technology: 'socketio',
    resources: { cpu: 45, ram: 62, disk: 78 },
    metrics: { uptime: 99.8, visitors: 1250, responseTime: 120 },
    paymentStatus: 'active',
    createdAt: '2024-01-15T10:00:00Z',
    lastDeploy: '2024-01-20T14:30:00Z',
  },
  {
    id: '2',
    name: 'Landing Page',
    userId: '2',
    clientName: 'João Silva',
    domain: 'landing.dls.com',
    port: 3001,
    status: 'running',
    technology: 'static',
    resources: { cpu: 12, ram: 28, disk: 45 },
    metrics: { uptime: 100, visitors: 890, responseTime: 80 },
    paymentStatus: 'active',
    createdAt: '2024-01-10T09:00:00Z',
    lastDeploy: '2024-01-18T11:15:00Z',
  },
  {
    id: '3',
    name: 'API Backend',
    userId: '3',
    clientName: 'Google User',
    domain: 'api.dls.com',
    port: 3002,
    status: 'stopped',
    technology: 'nodejs',
    resources: { cpu: 0, ram: 0, disk: 34 },
    metrics: { uptime: 85.2, visitors: 450, responseTime: 0 },
    paymentStatus: 'pending',
    createdAt: '2024-01-05T16:20:00Z',
    lastDeploy: '2024-01-12T13:45:00Z',
  },
];

const mockLogs: SystemLog[] = [
  {
    id: '1',
    applicationId: '1',
    level: 'info',
    message: 'Server started on port 3000',
    timestamp: '2024-01-20T14:30:15Z',
  },
  {
    id: '2',
    applicationId: '1',
    level: 'info',
    message: 'Socket.IO connection established',
    timestamp: '2024-01-20T14:32:22Z',
  },
  {
    id: '3',
    applicationId: '1',
    level: 'warning',
    message: 'High memory usage detected: 89%',
    timestamp: '2024-01-20T15:15:30Z',
  },
  {
    id: '4',
    applicationId: '2',
    level: 'info',
    message: 'Static files served successfully',
    timestamp: '2024-01-20T14:25:10Z',
  },
];

export const useApplicationStore = create<ApplicationState>((set, get) => ({
  applications: [],
  logs: [],
  isLoading: false,
  selectedApp: null,

  fetchApplications: async () => {
    set({ isLoading: true });
    await new Promise(resolve => setTimeout(resolve, 800));
    set({ applications: mockApplications, isLoading: false });
  },

  toggleApplicationStatus: async (appId: string) => {
    const applications = get().applications;
    const app = applications.find(a => a.id === appId);
    if (!app) return;

    set({ isLoading: true });
    
    // Simulate container operation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const newStatus = app.status === 'running' ? 'stopped' : 'running';
    const updatedApplications = applications.map(a =>
      a.id === appId
        ? {
            ...a,
            status: newStatus,
            resources: newStatus === 'running' ? a.resources : { cpu: 0, ram: 0, disk: a.resources.disk },
            metrics: newStatus === 'running' ? a.metrics : { ...a.metrics, responseTime: 0 },
          }
        : a
    );
    
    set({ applications: updatedApplications, isLoading: false });
  },

  removeApplication: async (appId: string) => {
    set({ isLoading: true });
    
    // Simulate backup and removal
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const applications = get().applications.filter(a => a.id !== appId);
    set({ applications, isLoading: false, selectedApp: null });
  },

  fetchLogs: async (appId: string) => {
    set({ isLoading: true });
    
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const appLogs = mockLogs.filter(log => log.applicationId === appId);
    set({ logs: appLogs, isLoading: false });
  },

  setSelectedApp: (app: Application | null) => {
    set({ selectedApp: app });
  },

  deployApplication: async (appData: any) => {
    set({ isLoading: true });
    
    // Simulate deploy process
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    const newApp: Application = {
      id: Date.now().toString(),
      name: appData.name,
      userId: appData.userId,
      clientName: appData.clientName,
      domain: `${appData.name.toLowerCase().replace(/\s+/g, '-')}.dls.com`,
      port: 3000 + Math.floor(Math.random() * 1000),
      status: 'running',
      technology: appData.technology,
      resources: { cpu: 25, ram: 35, disk: 50 },
      metrics: { uptime: 100, visitors: 0, responseTime: 95 },
      paymentStatus: 'active',
      createdAt: new Date().toISOString(),
      lastDeploy: new Date().toISOString(),
    };

    const applications = [...get().applications, newApp];
    set({ applications, isLoading: false });
  },
}));