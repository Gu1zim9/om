export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'client';
  avatar?: string;
  createdAt: string;
  googleId?: string;
}

export interface Application {
  id: string;
  name: string;
  userId: string;
  clientName: string;
  domain: string;
  port: number;
  status: 'running' | 'stopped' | 'deploying' | 'error';
  technology: 'nodejs' | 'python' | 'php' | 'static' | 'socketio';
  resources: {
    cpu: number;
    ram: number;
    disk: number;
  };
  metrics: {
    uptime: number;
    visitors: number;
    responseTime: number;
  };
  paymentStatus: 'active' | 'pending' | 'suspended';
  createdAt: string;
  lastDeploy: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  plan: 'basic' | 'pro' | 'enterprise';
  applications: Application[];
  subscription: Subscription;
  totalSpent: number;
  createdAt: string;
}

export interface Subscription {
  id: string;
  userId: string;
  plan: Plan;
  status: 'active' | 'suspended' | 'cancelled';
  currentPeriodEnd: string;
  stripeId?: string;
  mercadoPagoId?: string;
}

export interface Plan {
  id: string;
  name: string;
  price: number;
  currency: string;
  features: string[];
  limits: {
    applications: number;
    cpu: number;
    ram: number;
    storage: number;
  };
}

export interface Payment {
  id: string;
  userId: string;
  amount: number;
  status: 'paid' | 'pending' | 'failed' | 'refunded';
  method: 'stripe' | 'mercadopago';
  createdAt: string;
  paidAt?: string;
}

export interface SystemLog {
  id: string;
  applicationId?: string;
  level: 'info' | 'warning' | 'error';
  message: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

export interface DashboardMetrics {
  totalApplications: number;
  activeClients: number;
  monthlyRevenue: number;
  averageUptime: number;
  revenueChart: Array<{ month: string; revenue: number }>;
  recentApplications: Application[];
  pendingPayments: Payment[];
}